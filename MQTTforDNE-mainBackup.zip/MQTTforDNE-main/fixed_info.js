var type_and_serial = "No serial number";
var dne_version = "Not included in sample files.";
var dne_option = "Not included in sample files.";
var mqtt_host = "";
var mqtt_port = "";
var mqtt_username = "";
var mqtt_password = "";
